from __future__ import absolute_import

from scrapy import Request
from scrapy.linkextractors import LinkExtractor
from scrapy.loader import ItemLoader
from scrapy.loader.processors import Identity
from scrapy.spiders import Rule

from ..utils.spiders import BasePortiaSpider
from ..utils.starturls import FeedGenerator, FragmentGenerator
from ..utils.processors import Item, Field, Text, Number, Price, Date, Url, Image, Regex
from ..items import PortiaItem


class Linkedin(BasePortiaSpider):
    name = "www.linkedin.com"
    allowed_domains = [u'www.linkedin.com']
    start_urls = [
        u'https://www.linkedin.com/search/results/people/?keywords=meditation&origin=SWITCH_SEARCH_VERTICAL']
    rules = [
        Rule(
            LinkExtractor(
                allow=('.*'),
                deny=()
            ),
            callback='parse_item',
            follow=True
        )
    ]
    items = [[]]
